import java.util.Scanner;
import java.util.*;

 abstract class hotel_Admin{
    public int id, age ,count=0;
    public String name ;
    public double contactnum;
    private String u_name = "Faizan";
    private double pswrd  = 12345;

     hotel_Admin () // Constructor
     {
         this.contactnum = contactnum;
         this.u_name = u_name;
     }
   protected void login(String uu_name, double A_psd) {

         if (Objects.equals(uu_name, "Faizan") && A_psd == 12345)
         {
             System.out.println("Welcome Admin");
         }
         else {
             System.out.println("Invalid Credentials try again.. ");
             String opt;

                 System.out.println("Do you want to try again....???.... Y/N");
                 Scanner ss = new Scanner(System.in);
                 opt = ss.next();
//             System.exit(0);
         }
     }

     public void create(){
         Scanner cr = new Scanner(System.in);
         System.out.println("Adding new user by admin");
         System.out.println("Enter ID of user: ");
         id = cr.nextInt();
         System.out.println("Enter name of user: ");
         name = cr.next();
         System.out.println("Enter age of user: ");
         age = cr.nextInt();
         System.out.println("Enter Contact num of user: ");
         contactnum = cr.nextDouble();
         System.out.println("New user Add successfully.....");
         count++;
     }
     public void Display()
     {
         System.out.println("=======================");
         System.out.println("New user details are :");
         System.out.println("=======================");
         System.out.println("Total number of new users are : " + count);
         System.out.println("User id is     :" + id);
         System.out.println("User Name is   :" + name);
         System.out.println("User age is    :" + age);
         System.out.println("User Phone# is :" + contactnum);

     }

    public void update()
    {
        System.out.println("Update method of admin class");
        System.out.println("Under development");
    }}

////////==============///////
//////// INHERITANCE  ///////
////////==============///////

class customer extends hotel_Admin
{
    customer()
    {

    }

    public void enableUser() {
        System.out.println("Enable User method in customer class");
        System.out.println("Under development");

    }
    public void disableUser()
    {
        System.out.println("Disable User method in customer class");
        System.out.println("Under development");

    }}

class Employee extends hotel_Admin
{
    Employee(){

    }
    public void add()
    {
        System.out.println("Add method in Employee class");
        System.out.println("Under development");


    }

    public void Update()
    {
        System.out.println("Update method in Employee for update user data");
        System.out.println("Under development");

    }}

class Transaction{
    public int id;
    public double number;
    public String date;

////////==============///////
//////// Association  ///////
////////==============///////

    public String getDate() {
      return date;
    }

    public void setDate()
    {
        this.date = date;
    }

    Transaction(){
        this.number = number;
    }
    public void processDebit()
    {
        System.out.println("Debit Method in transaction");
        System.out.println("Under development");

    }}

class Reservation{

    public int id;
    public double amount;
    public String date;
    public String receipt;

    List<Transaction> numbers;

    public double getAmount(){
        return amount;
    }

    public void setAmount()
    {
        this.amount = amount;
    }
    public List<Transaction> getNumbers(){
        return numbers;
    }

    public void setNumbers(List<Transaction> numbers){
        this.numbers = numbers;

        /////   Later on we will call this in main
        //// List<Transaction> numberList = new ArrayList<Transaction>();
        /// numberList.add()
         }

    public void update()
    {
        System.out.println("Update in Reservation class");
        System.out.println("Under development");

    }}


////////==============///////
//////// Composition  ///////
////////==============///////
class payment{

    payment ()
    {
        double collect_payment;
    }

    public void add()
    {
        System.out.println("Add method in Payment");
        System.out.println("Under development");

    }
    public void Update()
    {
        System.out.println("Update method in Payment");
        System.out.println("Under development");

    }}

class Room {
    public int id;
    public String details;
    public String req;
    public String date;

    private final List<payment> payments;
    Room (List<payment> payments, List<payment> payments1)
    {

        this.payments = payments1;
    }

    public Room(List<payment> payments) {

        this.payments = payments;
    }

    public List<payment> getPayments(){
        return payments;
    }

    // later on we will call this in main like
    // List <payment> pay = new ArrayList<pay>();
    /// Room r = new Room();
    // List <payment> p= r.getPayments;



    public void update()
    {
        System.out.println("Update in Room class");
        System.out.println("Under development");

    }}

class other    // separate class for extra work
{
    public void intro(){
        System.out.println("=====================================================");
        System.out.println("    [Online Restaurants Management System (RMS)]     ");
        System.out.println("====================================================");
        System.out.println("Developed by:");
        System.out.println("-------------");
        System.out.println("Muhammad Faizan  ((20-Arid-793))");
        System.out.println("BSSE-5B-MOR");
        System.out.println("-----------");
    }
    public void options()
    {
        System.out.println("Select your desired option : ");
        System.out.println("Press 1 for add user ");
        System.out.println("Press 2 for chk User details");
        System.out.println("Press 3 for check payment");
        System.out.println("Press 4 for Total Transactions");
        System.out.println("Press 5 for Room details");
        System.out.println("Press 6 for Exit");
    }}
public class Main {
    public static void main(String[] args) {
        customer c = new customer();// Creating an object for all classes
        Employee e = new Employee();
        payment p = new payment();
        Transaction t = new Transaction();
        Reservation r = new Reservation();
        List<payment> payments;
//        Room rm = new Room();
        Scanner sc = new Scanner(System.in);
        other o = new other();
        o.intro();

            System.out.println("Enter your name");
            String uu_name = sc.next();
            System.out.println("Enter Password");
            double psd = sc.nextInt();
            c.login(uu_name, psd);

        o.options();
        int ch = sc.nextInt();
        switch (ch)
        {
            case 1: {
                 c.create();
                 c.Display();
            }
                 break;
            case 2: {
                r.update();
            }
            break;
            case 3: {
                p.add();
                p.Update();
            }
            break;
            case 4: {
                t.processDebit();
            }
            break;
            case 5:
            {
    //            rm.update();
            }
            break;
            case 6:
            {
                System.exit(0);
            }

            default:
            {
                System.out.println("Invalid choice try again...");
            }
        }
    }

}